

<?php $__env->startSection('konten'); ?>

<h2 class="intro-y text-lg font-medium mt-10">List Mahasiswa</h2>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
           <a href="<?php echo e(route('dashboardcreate')); ?>"> <button class="btm btn-primary shadow-md mr-2">Tambah Buku</button></a>
            <div class="hidden md:block mx-auto text-slate-500">Showing list data entries</div>
            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
            </div>
        </div>
        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
            <table class="table table-report -mt-2">
                <thead>
                    <tr>
                        <th class="whitespace-nowrap">Nama</th>
                        <th class="text-center whitespace-nowrap">Tempat Lahir</th>
                        <th class="text-center whitespace-nowrap">Tanggal Lahir</th>
                        <th class="text-center whitespace-nowrap">Jenis Kelamin</th>
                        <th class="text-center whitespace-nowrap">Alamat</th>
                        <th class="text-center whitespace-nowrap">Agama</th>
                        <th class="text-center whitespace-nowrap">Kota</th>
                        <th class="text-center whitespace-nowrap">Kabupaten</th>
                        <th class="text-center whitespace-nowrap">Provinsi</th>
                        <th class="text-center whitespace-nowrap">Kode Pos</th>
                        <th class="text-center whitespace-nowrap">No-telp</th>
                        <th class="text-center whitespace-nowrap">Email</th>
                        <th class="text-center whitespace-nowrap">Status Calon Mahasiswa</th>
                        <th class="text-center whitespace-nowrap">Asal Sekolah</th>
                        <th class="text-center whitespace-nowrap">Alamat Sekolah</th>
                        <th class="text-center whitespace-nowrap">Nilai Ratarata Rapor</th>
                        <th class="text-center whitespace-nowrap">Tahun Lulus</th>
                        <th class="text-center whitespace-nowrap">Periode Masuk</th>
                        <th class="text-center whitespace-nowrap">Jenjang Pendidikan</th>
                        <th class="text-center whitespace-nowrap">Program Studi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="intro-x">
                            <td>
                                <div class="text-slate-500"><?php echo e($value['nama']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['tempat_lahir']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['jenis_kelamin']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['alamat']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['agama']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['kota']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['kabupaten']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['provinsi']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['kode_pos']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['no_telp']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['email']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['status_calon_mahasiswa']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['asal_sekolah']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['alamat_sekolah']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['nilai_ratarata_rapor']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['tahun_lulus']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['periode_masuk']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['jenjang_pendidikan']); ?></div>
                            </td>
                            <td>
                                <div class="text-slate-500"><?php echo e($value['program_studi']); ?></div>
                            </td>
                            
                            <td class="table-report__action w-56">
                                <div class="flex justify-center items-center">
                                    <a class="flex items-center mr-3" href="javascript:;">
                                        <i data-feather="check-square" class="w-4 h-4 mr-1"></i> Edit
                                    </a>
                                    <a class="flex items-center text-danger" href="javascript:;">
                                        <i data-feather="trash-2" class="w-4 h-4 mr-1"></i> Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>    
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rekwebUAS\uasrekweb\uasrekweb\resources\views/Dashboard/index.blade.php ENDPATH**/ ?>